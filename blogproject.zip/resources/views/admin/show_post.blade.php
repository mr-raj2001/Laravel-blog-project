<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #007BFF;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .img_deg{
            height:100px;
            width:150px;
            padding: 4px;
        }
    </style>
    @include('admin.css')
</head>
  
    @include('admin.css')
  
  <body>
    @include('admin.header')
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      @include('admin.sidebar')
      
      <div class="page-content">
      
      <table>
        <thead>
            <tr>
                <th>Post Title</th>
                <th>Description</th>
                <th>Post By</th>
                <th>Post Status</th>
                <th>User Type</th>
                <th>Image</th>
                <th>Delete</th>
                <th>Edit</th>

            </tr>
        </thead>
        <tbody>

        @foreach ($post as $post)
            <tr>
                <td>{{$post->title}}</td>
                <td>{{$post->description}}</td>
                <td>{{$post->name}}</td>
                <td>{{$post->post_status}}</td>
                <td>{{$post->usertype}}</td>
                <td><img class="img_deg" src="postimage/{{$post->image}}"></td>
                <td><a href="{{url('delete_post',$post->id)}}" class="btn btn-danger">Delete</a></td>
                <td><a href="{{url('edit_page',$post->id)}}" class="btn btn-success">Edit</a></td>
            </tr>

           @endforeach 
           
            <!-- Add more rows as needed -->
        </tbody>
    </table>

    </div>

      <!-- Sidebar Navigation end-->
      
        
        @include('admin.footer');
  </body>
</html>
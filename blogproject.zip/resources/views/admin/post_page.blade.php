<!DOCTYPE html>
<html>
  <head>
  @include('admin.css')
  <style>
     body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
        }

        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group input[type="file"] {
            width: 100%;
            padding: 10px;
        }

        .submit-button {
            background-color: #007BFF;
            color: red;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .submit-button:hover {
            background-color: #0056b3;
        }

  </style>
  </head>
    
  
  <body>
    @include('admin.header')
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      @include('admin.sidebar')
      <!-- Sidebar Navigation end-->
      <div class="page-content">
      <div class="container">
        <h1>Add a Post</h1>
        <form action="{{url('add_post')}}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="post-title">Post Title:</label>
                <input type="text" id="post-title" name="title" required>
            </div>

            <div class="form-group">
                <label for="post-description">Post Description:</label>
                <textarea id="post-description" name="description" rows="4" required></textarea>
            </div>

            <div class="form-group">
                <label for="post-image">Post Image:</label>
                <input type="file" id="post-image" name="image" accept="image/*" >
            </div>

            <div class="form-group">
                <button type="submit" class="submit-button">Submit</button>
            </div>
        </form>
    </div>
        </div>
       
        @include('admin.footer')
  </body>
</html>
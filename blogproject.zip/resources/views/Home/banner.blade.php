<div class="banner_section layout_padding">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <div class="container">
                        <h1 class="banner_taital">Adventure</h1>
                        <p class="banner_text">"Adventure: Where the extraordinary becomes your everyday."</p>
                       
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <h1 class="banner_taital">Sports</h1>
                        <p class="banner_text">"Sports: Where passion meets the pursuit of excellence."</p>
                        
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <h1 class="banner_taital">Trekking</h1>
                        <p class="banner_text">"Trekking: Embrace the path less traveled."</p>
                        
                     </div>
                  </div>
               </div>
            </div>
         </div>
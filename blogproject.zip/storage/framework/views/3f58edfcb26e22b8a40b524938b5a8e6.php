<!DOCTYPE html>
<html lang="en">
   <head>
      <?php echo $__env->make('home.homecss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </head>
   <body>
      <!-- header section start -->
      <div class="header_section">
         <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- banner section start -->
         <?php echo $__env->make('home.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- banner section end -->
      </div>
      <!-- header section end -->
      <!-- services section start -->
      <?php echo $__env->make('home.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- services section end -->
      <!-- about section start -->
      <?php echo $__env->make('home.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- blog section end -->
      <!-- client section start -->
     
      <!-- choose section end -->
      <!-- footer section start -->
      <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html><?php /**PATH D:\blogproject\resources\views/home/homepage.blade.php ENDPATH**/ ?>
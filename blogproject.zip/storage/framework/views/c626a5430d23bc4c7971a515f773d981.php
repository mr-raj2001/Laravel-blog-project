<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #007BFF;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .img_deg{
            height:100px;
            width:150px;
            padding: 4px;
        }
    </style>
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
  
    <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      <div class="page-content">
      
      <table>
        <thead>
            <tr>
                <th>Post Title</th>
                <th>Description</th>
                <th>Post By</th>
                <th>Post Status</th>
                <th>User Type</th>
                <th>Image</th>
                <th>Delete</th>
                <th>Edit</th>

            </tr>
        </thead>
        <tbody>

        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->description); ?></td>
                <td><?php echo e($post->name); ?></td>
                <td><?php echo e($post->post_status); ?></td>
                <td><?php echo e($post->usertype); ?></td>
                <td><img class="img_deg" src="postimage/<?php echo e($post->image); ?>"></td>
                <td><a href="<?php echo e(url('delete_post',$post->id)); ?>" class="btn btn-danger">Delete</a></td>
                <td><a href="<?php echo e(url('edit_page',$post->id)); ?>" class="btn btn-success">Edit</a></td>
            </tr>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
           
            <!-- Add more rows as needed -->
        </tbody>
    </table>

    </div>

      <!-- Sidebar Navigation end-->
      
        
        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  </body>
</html><?php /**PATH D:\blogproject\resources\views/admin/show_post.blade.php ENDPATH**/ ?>
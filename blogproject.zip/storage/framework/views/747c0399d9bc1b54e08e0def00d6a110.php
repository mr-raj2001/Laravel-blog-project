

<!DOCTYPE html>
<html lang="en">
   <head>

   <base href="/public">
      <?php echo $__env->make('home.homecss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </head>
   <body>
      <!-- header section start -->
      <div class="header_section">
         <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>  
<div style="text-align: center;" class="services_section_2">
               <div class="row">

             
                  <div class="col-md-12">
                     <div><img src="/postimage/<?php echo e($post->image); ?>" class="services_img" style="padding: 20px"></div>
                     <h3><?php echo e($post->title); ?></h3>
                     <h4><?php echo e($post->description); ?></h4>
                     <p>Post by <b><?php echo e($post->name); ?></b></p>
                     
                  </div>

             
                 
               </div>
            </div>

        
      <!-- footer section start -->
      <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </body>
</html><?php /**PATH D:\blogproject\resources\views/home/post_details.blade.php ENDPATH**/ ?>